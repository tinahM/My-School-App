# My-School-App

This is the completed Navgation Bar for the Admin most of what will be included is read from the database so that is what is left
