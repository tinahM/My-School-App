package com.tinah.myschoolapp;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.widget.Adapter;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import java.util.ArrayList;

import android.os.Bundle;

public class AppBase extends AppCompatActivity {
     ArrayList<String> basicFields;
    GridAdapter adapter;
    public static ArrayList<String> divisions ;
     GridView gridView;
    public static databaseHandler handler;
    public static Activity activity;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.mai_menu, menu);
        return true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_layout);
        basicFields = new ArrayList<>();
        handler = new databaseHandler(this);
        activity = this;
        getSupportActionBar().show();
        divisions = new ArrayList();
        divisions.add("ICS UNIT 1");
        divisions.add("ICS UNIT 2");
        divisions.add("ICS UNIT 3");
        divisions.add("ICS UNIT 4");
        divisions.add("ICS UNIT 5");

        gridView = (GridView)findViewById(R.id.grid);
        basicFields.add("ATTENDANCE");
        //basicFields.add("SCHEDULER");
        //basicFields.add("NOTES");
        basicFields.add("PROFILE");
        basicFields.add("COURSEWORK");
        basicFields.add("CGPA CALCULATOR");
        adapter = new GridAdapter(this,basicFields);
        gridView.setAdapter(adapter);
    }
   /* public void loadSettings(MenuItem item) {
        Intent launchIntent = new Intent(this,SettingsActivity.class);
        startActivity(launchIntent);
    }
    public void loadAbout(MenuItem item) {
        Intent launchIntent = new Intent(this,About.class);
        startActivity(launchIntent);
    }*/
}